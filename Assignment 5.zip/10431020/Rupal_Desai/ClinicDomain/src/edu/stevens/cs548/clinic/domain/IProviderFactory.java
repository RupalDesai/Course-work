package edu.stevens.cs548.clinic.domain;

//import java.util.Date;

public interface IProviderFactory {
	public Provider createProvider (long NPI,String pro_name) throws IProviderDAO.ProviderExn;
}
