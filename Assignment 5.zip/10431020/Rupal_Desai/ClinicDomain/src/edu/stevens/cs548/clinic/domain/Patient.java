package edu.stevens.cs548.clinic.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import static javax.persistence.CascadeType.REMOVE;
import javax.persistence.*;
import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;


/*
 * TODO
 */
@Entity
@NamedQueries({
	@NamedQuery(
		name="SearchPatientByPatientID",
		query="select p from Patient p where p.patientId = :pid"),
	@NamedQuery(
		name="CountPatientByPatientID",
		query="select count(p) from Patient p where p.patientId = :pid"),
	@NamedQuery(
		name = "RemoveAllPatients", 
		query = "Delete from Patient p")
})



public class Patient implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private static final CascadeType[] c = null;
	@Id
	@GeneratedValue
	// TODO JPA annotations
	private long id;
//	private static final CascadeType[] = null;
	
	private long patientId;
	
	private String name;
	
	// TODO JPA annotation
	@Temporal(TemporalType.DATE)
	private Date birthDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	
	@OneToMany(cascade = REMOVE, mappedBy="patient")
	@OrderBy
	private List<Treatment> treatments;

	protected List<Treatment> getTreatments() {
		return treatments;
	}

	protected void setTreatments(List<Treatment> treatments) {
		this.treatments = treatments;
	}
	
	@Transient
	private ITreatmentDAO treatmentDAO;
	
	public void setTreatmentDAO (ITreatmentDAO tdao) {
		this.treatmentDAO = tdao;
	}
	
	public long addTreatment (Treatment t) {
		// Persist treatment and set forward and backward links
		this.treatmentDAO.addTreatment(t);
		this.getTreatments().add(t);
		if (t.getPatient() != this) {
			t.setPatient(this);
		}
		return t.getId();
	}
	public void addDrugTreatment(String diagnosis,String drug,float dosage,long NPI,String provider_name){
	//add provider parameter
		Provider pro=new Provider();
		DrugTreatment dt=new DrugTreatment();
		pro.setNPI(NPI);
		pro.setProvider_name(provider_name);
		dt.setDiagnosis(diagnosis);
		dt.setDrug(drug);
		dt.setDosage(dosage);
		this.addTreatment(dt);
	}
	public void addSurgery(String diagnosis,Date date,long NPI,String provider_name){
		//add provider parameter
		Provider pro=new Provider();
		Surgery s=new Surgery();
		pro.setNPI(NPI);
		pro.setProvider_name(provider_name);
		s.setDate(date);
		s.setDiagnosis(diagnosis);
		this.addTreatment(s);
	}
	
	public void addRadiology(String diagnosis,List<Date> dates,long NPI,String provider_name){
		Radiology r=new Radiology();
		Provider pro=new Provider();
		pro.setNPI(NPI);
		pro.setProvider_name(provider_name);
		r.setDates(dates);
		r.setDiagnosis(diagnosis);
		this.addTreatment(r);
	}
	public List<Long> getTreatmentIds(List<Long> treatmentIds) {
		for (Treatment t : this.getTreatments()) {
			treatmentIds.add(t.getId());
		}
		return treatmentIds;
	}
	public <T> T exportTreatment(long tid, ITreatmentExporter<T> visitor) throws TreatmentExn {
		// Export a treatment without violated Aggregate pattern
		// Check that the exported treatment is a treatment for this patient.
		Treatment t = treatmentDAO.getTreatmentById(tid);
		if (t.getPatient() != this) {
			throw new TreatmentExn("Inappropriate treatment access: patient = " + id + ", treatment = " + tid);
		}
		return t.export(visitor);
	}

	public Patient() {
		super();
		/*
		 * TODO initialize lists
		 */
		treatments=new ArrayList<Treatment>();
	}
   
}
