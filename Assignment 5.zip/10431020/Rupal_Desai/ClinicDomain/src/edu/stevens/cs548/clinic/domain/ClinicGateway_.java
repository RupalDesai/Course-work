package edu.stevens.cs548.clinic.domain;

import javax.annotation.Generated;
import javax.persistence.EntityManagerFactory;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2017-10-15T02:53:24.901+0530")
@StaticMetamodel(ClinicGateway.class)
public class ClinicGateway_ {
	public static volatile SingularAttribute<ClinicGateway, EntityManagerFactory> emf;
}
