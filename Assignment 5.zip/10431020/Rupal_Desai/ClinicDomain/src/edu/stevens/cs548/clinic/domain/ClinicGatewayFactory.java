package edu.stevens.cs548.clinic.domain;

public class ClinicGatewayFactory {
	public static ClinicGateway createClinicGateway(){
		return new ClinicGateway();
	}

}
