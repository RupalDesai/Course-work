package edu.stevens.cs548.clinic.domain;

import static javax.persistence.CascadeType.REMOVE;

import java.io.Serializable;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;

/**
 * Entity implementation class for Entity: Provider
 *
 */
@Entity
@NamedQueries({
	@NamedQuery(
		name="SearchProviderByNPI",
		query="select p from Provider p where p.NPI = :pid"),
	@NamedQuery(
		name="CountProviderByNPI",
		query="select count(p) from Provider p where p.NPI = :pid"),
	@NamedQuery(
		name = "RemoveAllProviders", 
		query = "delete from Provider p")
})


public class Provider implements Serializable {

	@Id
	private long NPI;
	
	private String provider_name;   
	
	private static final long serialVersionUID = 1L;

	
 
	public String getProvider_name() {
		return this.provider_name;
	}

	public void setProvider_name(String provider_name) {
		this.provider_name = provider_name;
	}   
	public long getNPI() {
		return this.NPI;
	}

	public void setNPI(long NPI) {
		this.NPI = NPI;
	}

	@OneToMany(cascade=REMOVE, mappedBy="provider")
    @OrderBy
private List<Treatment> treatments;

protected List<Treatment> getTreatments() {
	return treatments;
}

protected void setTreatments(List<Treatment> treatments) {
	this.treatments = treatments;
}
//Patient p= new Patient();
@Transient
private ITreatmentDAO treatmentDAO;

public void setTreatmentDAO (ITreatmentDAO tdao) {
	this.treatmentDAO = tdao;
}

public long addTreatment(Treatment t){
	
	this.treatmentDAO.addTreatment(t);
	Patient p = t.getPatient();
      p.addTreatment(t);
	  this.getTreatments().add(t);
	  if(t.getProvider()!=this)
	  t.setProvider(this);
	  return t.getId();
	 
}
public List<Long> getTreatmentIds(List<Long> treatmentIds) {
	for (Treatment t : this.getTreatments()) {
		treatmentIds.add(t.getId());
	}
	return treatmentIds;
}
public <T> void exportTreatment(long tid, ITreatmentExporter<T> visitor) throws TreatmentExn {
	// Export a treatment without violated Aggregate pattern
	// Check that the exported treatment is a treatment for this patient.
	Treatment t = treatmentDAO.getTreatmentById(tid);
	if (t.getProvider() != this) {
		throw new TreatmentExn("Inappropriate treatment access: patient = " + NPI + ", treatment = " + tid);
	}
	t.export(visitor);
}

	public Provider() {
		super();
		treatments= new ArrayList<Treatment>();
	}   
}
