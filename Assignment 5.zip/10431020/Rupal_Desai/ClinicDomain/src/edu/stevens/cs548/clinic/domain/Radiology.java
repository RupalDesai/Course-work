package edu.stevens.cs548.clinic.domain;

import edu.stevens.cs548.clinic.domain.Treatment;
import java.io.Serializable;

import javax.persistence.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
/**
 * Entity implementation class for Entity: Radiology
 *
 */
@Entity
@DiscriminatorValue("R")

public class Radiology extends Treatment implements Serializable {
    
	private static final long serialVersionUID = 1L;
	
	@ElementCollection
	@Temporal(TemporalType.DATE)
	@CollectionTable(
			name="rdates",
			joinColumns=@JoinColumn(name="id")
			)
   @Column(name ="radiologydates")
	private List<Date> dates;

   public List<Date> getDates() {
		return dates;
	}

	public void setDates(List<Date> dates) {
		this.dates = dates;
	}

public Radiology() {
		super();
		this.setTreatmentType("R");
		
	}
//Provider pro=new Provider();
@Override
public <T>T export(ITreatmentExporter<T> visitor) {
	// TODO Auto-generated method stub
	
	return  visitor.exportRadiology(this.getId(), 
   		   this.getDiagnosis(),
	   		   this.getDates());
	   		 
}   
	
   
}
