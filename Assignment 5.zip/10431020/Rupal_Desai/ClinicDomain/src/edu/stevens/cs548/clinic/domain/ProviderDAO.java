package edu.stevens.cs548.clinic.domain;

//import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;
import java.util.*;
import javax.persistence.Query;
public class ProviderDAO implements IProviderDAO {
	private EntityManager em;
	private TreatmentDAO treatmentDAO;
	
	public ProviderDAO(EntityManager em) {
		this.em = em;
		this.treatmentDAO = new TreatmentDAO(em);
	}
	@Override
	public long addProvider(Provider pro) throws ProviderExn {
		// TODO Auto-generated method stub
		long pid=pro.getNPI();
		TypedQuery<Provider> query=em.createNamedQuery("SearchProviderByNPI",Provider.class).setParameter("pid", pid);
		List<Provider> provider=query.getResultList();
		if(provider.size()<1)
			
		{
			em.persist(pro);
			pro.setTreatmentDAO(this.treatmentDAO);
			
		}
		else
		{
			Provider provider1=provider.get(0);
			throw new ProviderExn("Insertion: Provider with provider id"+pid+"already exisits"+provider1.getProvider_name());
		}
		return pid;
	}

	@Override
	public Provider getProviderByNPI(long pid) throws ProviderExn {
		// TODO Auto-generated method stub
		TypedQuery<Provider>query=
				em.createNamedQuery("SearchProviderByNPI",Provider.class).setParameter("pid", pid);
		List<Provider> providers=query.getResultList();
		if(providers.size()>1)
		{
			throw new ProviderExn("Duplicate provider records:provider npi"+pid);
			
		}
		else{
		   Provider pro=providers.get(0);
		   pro.setTreatmentDAO(this.treatmentDAO);
			return pro;
			}
 
	}


	@Override
	public void deleteProviders() {
		// TODO Auto-generated method stub
		Query update=(Query) em.createNamedQuery("RemoveAllProviders");
		update.executeUpdate()
;	}

}
