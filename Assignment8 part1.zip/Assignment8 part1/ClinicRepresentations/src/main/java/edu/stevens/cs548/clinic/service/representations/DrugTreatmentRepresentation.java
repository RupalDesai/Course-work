package edu.stevens.cs548.clinic.service.representations;

import edu.stevens.cs548.clinic.service.web.rest.data.DrugTreatmentType;

public class DrugTreatmentRepresentation extends DrugTreatmentType {
	
	public DrugTreatmentRepresentation (DrugTreatmentType drug){
		this.setDosage(drug.getDosage());
		this.setName(drug.getName());
	}
	
	

}
