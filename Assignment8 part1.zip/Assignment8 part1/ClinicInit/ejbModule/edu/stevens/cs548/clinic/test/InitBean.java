package edu.stevens.cs548.clinic.test;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.ejb.LocalBean;
import javax.ejb.Singleton;
import javax.ejb.Startup;
import javax.inject.Inject;

import edu.stevens.cs548.clinic.domain.DrugTreatment;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IProviderDAO.ProviderExn;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.PatientFactory;
import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.domain.ProviderDAO;
import edu.stevens.cs548.clinic.domain.ProviderFactory;
import edu.stevens.cs548.clinic.domain.Radiology;
import edu.stevens.cs548.clinic.domain.Surgery;
import edu.stevens.cs548.clinic.domain.Treatment;
import edu.stevens.cs548.clinic.domain.TreatmentFactory;
import edu.stevens.cs548.clinic.service.dto.util.PatientDto;
import edu.stevens.cs548.clinic.service.dto.util.PatientDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDtoFactory;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientServiceLocal;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceLocal;

/**
 * Session Bean implementation class TestBean
 */
@Singleton
@LocalBean
@Startup
public class InitBean {

	private static Logger logger = Logger.getLogger(InitBean.class.getCanonicalName());

	/**
	 * Default constructor.
	 */
	public InitBean() {
	}
	
	public static void info(String m) {
		logger.info(m);
	}
	
	private Date setDate(String stringDate) {
		Date date = null;
		try {
			String pattern = "MM/dd/yyyy";
			SimpleDateFormat format = new SimpleDateFormat(pattern);
			date = format.parse(stringDate);
		} catch (Exception e) {
			IllegalStateException ex = new IllegalStateException("Error while setting the date");
			ex.initCause(e);
			throw ex;
		}
		return date;
	}
	
	@Inject
	IPatientServiceLocal patientService;
	@Inject
	IProviderServiceLocal providerService;

	@PostConstruct
	private void init() {
		/*
		 * Put your testing logic here. Use the logger to display testing output in the server logs.
		 */
		logger.info("Your name here: Rupal Desai");
		
		logger.info("Factors");
		PatientFactory patientFactory = new PatientFactory();
		TreatmentFactory treatmentFactory = new TreatmentFactory();
		ProviderFactory providerFactory = new ProviderFactory();
		
		PatientDtoFactory patientdtoFactory = new PatientDtoFactory();
	    PatientDto patientdto;

		
		ProviderDtoFactory providerdtoFactory = new ProviderDtoFactory();
        ProviderDto providerdto;

		
		TreatmentDtoFactory treatmentdtoFactory = new TreatmentDtoFactory();
	    TreatmentDto treatmentDto;

		
	    
	    patientService.deletePatients();
		providerService.deleteProvider();

		try {
			
			//Patient
			logger.info("Adding Patient");
			Patient pat1 = patientFactory.createPatient(1234L, "abc", setDate("09/27/1995"), 21);
			patientdto = patientdtoFactory.createPatientDto(pat1,21);
			long pat_id=patientService.addPatient(patientdto);
			logger.info("Added Patient "+pat1.getName()+" with id "+pat_id);
			
			//Provider
			logger.info("Adding provider");
			Provider pro1 = providerFactory.createProvider(1256, "John Cena","Physician");
			providerdto=providerdtoFactory.createProviderDto(pro1);
			long pro_id= providerService.addProvider(providerdto);
			logger.info("Added Provider: with name:"+pro1.getName()+" with npi "+pro_id);
			

			//Adding Surgery
			logger.info("Adding A Surgery treatment ..");
			Treatment s = treatmentFactory.createSurgeryTreatment("qarl",setDate("02/03/2014"));
			treatmentDto = treatmentdtoFactory.createSurgeryTreatmentdto((Surgery) s);
			treatmentDto.setPatient(pat_id);
			treatmentDto.setProvider(pro_id);
			long surgery_id =providerService.addTreatment(treatmentDto);
			logger.info("(Surgery)Provider : " + pro1.getName() + " treatment id " + surgery_id + " for patient "+ pat1.getName());

			
		} catch (PatientExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (PatientServiceExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProviderServiceExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
