package edu.stevens.cs548.clinic.domain;

import java.util.List;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

//import edu.stevens.cs548.clinic.domain.Provider.Specialization;

public class ProviderDAO implements IProviderDAO {

	@PersistenceContext
	private EntityManager em;
    private TreatmentDAO treatmentDAO; 
    
    public ProviderDAO(EntityManager em){
    	this.em=em;
		this.treatmentDAO = new TreatmentDAO(em);
    }
    
    @SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(PatientDAO.class.getCanonicalName());
    
    
    
    
	public Provider getProviderByNPI(long npi) throws ProviderExn {
		TypedQuery<Provider> query =  em.createNamedQuery("SearchProviderBynpi",Provider.class).setParameter("pid", npi);
		List<Provider> providerL = query.getResultList();
		
		if (providerL.isEmpty() || providerL.size() > 1) {
			throw new ProviderExn("Ambiguious result : "+providerL.size());
		} else {
			Provider provider = providerL.get(0);
			provider.setTreatmentDAO(this.treatmentDAO);
		
			return provider;
		}
	}

	@Override
	public Provider getProviderByDbId(long id) throws ProviderExn {
		Provider provider = em.find(Provider.class, id);
		if (provider == null) {
			throw new ProviderExn("No provider Found with the provided Id");
		} else {
			logger.info("into dao provider name is:"+provider.getId()+" "+provider.getNpi());
			provider.setTreatmentDAO(this.treatmentDAO);
			return provider;
		}
	}

	@Override
	public List<Provider> getProviderByNameSpec(String name, String spec) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long addProvider(Provider prv) throws ProviderExn {
		long npi = prv.getNpi();
		Query query = em.createNamedQuery("CountProviderBynpi").setParameter("pid", npi);
		Long numExisting = (Long) query.getSingleResult();
		if (numExisting < 1) {
			try {
				
				em.persist(prv);
				em.flush();
				prv.setTreatmentDAO(this.treatmentDAO);
				
			} catch (Exception e) {
				throw new IllegalStateException("Unimplemented");				
			}
       return prv.getId();
			
		} else {
			throw new ProviderExn("Insertion: Provider with provider id (" + npi + ") already exists.");
		}

	}

	@Override
	public void delProvider(Provider prv) throws ProviderExn {
		// TODO Auto-generated method stub
		em.remove(prv);
	}

	@Override
	public void delProviders() {
		em.createQuery("delete from Treatment t").executeUpdate();
		Query update = em.createNamedQuery("RemoveAllProvider");
		update.executeUpdate();
		
	}
	

}
