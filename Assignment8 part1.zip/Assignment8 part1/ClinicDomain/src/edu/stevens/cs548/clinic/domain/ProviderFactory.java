package edu.stevens.cs548.clinic.domain;



public class ProviderFactory implements IProviderFactory {

	@Override
	public Provider createProvider(long npi, String name, String spec) {
		Provider pr = new Provider();
		pr.setNpi(npi);
		pr.setName(name);
		pr.setSpecialization(spec);
		return pr;
	}

}
