package edu.stevens.cs548.clinic.domain;

import java.util.*;
import java.util.List;
import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;



public class PatientDAO implements IPatientDAO {
	@PersistenceContext
	private EntityManager em;
    private TreatmentDAO treatmentDAO; 
	
    @Override
	public Patient getPatientByPatientId(long patient_id) throws PatientExn {
		TypedQuery<Patient> query=em.createNamedQuery("SearchPatientByPatientID", Patient.class)
				.setParameter("pid", patient_id);
		List<Patient> patients = query.getResultList();
		if(patients.size()>1)
			throw new PatientExn("Duplicate Patient Record: patient id="+patient_id);
		else if(patients.size()<1){
			throw new PatientExn("Patient not found: patient id="+patient_id);
		}
		else
			{
			Patient p = patients.get(0);
			p.setTreatmentDAO(this.treatmentDAO);
			return p;
			}
		
	}

	
	@Override
	public Patient getPatientByDbId(long id) throws PatientExn {
		Patient p = em.find(Patient.class,id);
	
		if(p==null){
			logger.info("not found");
			throw new PatientExn("Patient not found: primary key="+id);
		}
		else{
			logger.info("patient name is:"+p.getName()+" "+p.getId()+" "+p.getPatientId());
			p.setTreatmentDAO(this.treatmentDAO);
			return p;
		}
	}
	
	

	@Override
	public List<Patient> getPatientdob(String pname, Date dob) {
		TypedQuery<Patient> query=em.createNamedQuery("SearchPatientByNameDOB", Patient.class)
				.setParameter("name", pname)
				.setParameter("dob", dob);
		List<Patient> patients = query.getResultList();
		for(Patient p: patients){
			p.setTreatmentDAO(this.treatmentDAO);
		}
		return patients;
	}

	
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(PatientDAO.class.getCanonicalName(), null);

	

	@Override
	public Patient getPatient(long id) throws PatientExn {
		Query q = em.createNamedQuery("CountPatientByID").setParameter("pid", id);
		Long num = (Long) q.getSingleResult();
		
		if(num < 1 || num > 1){
			throw new PatientExn ("No patient record"+id);
		}
		else{
			Patient patient = em.find(Patient.class, id);
			if (patient == null) {
				throw new PatientExn("No patient Found with the provided Id");
			} else {
				patient.setTreatmentDAO(this.treatmentDAO);
				return patient;
			}
		}
	}
	@Override
	public long addPatient(Patient patient) throws PatientExn {
		long pid = patient.getPatientId();
		Query q = em.createNamedQuery("CountPatientByPatientID").setParameter("pid", pid);
		Long num = (Long) q.getSingleResult();
		if (num < 1) {
			try {
                em.persist(patient);
				em.flush();
				patient.setTreatmentDAO(this.treatmentDAO);
			} catch (Exception e) {
				throw new IllegalStateException("Not implemented" + e.getMessage());				
			}
			return patient.getId();
			
		} else {
			throw new PatientExn("Patient already exist with id"+ pid);
		}
	}
	


	@Override
	public void delPatient(Patient patient) throws PatientExn {

		em.remove(patient);}
	
	@Override
	public void deletePatients() {
		em.createQuery("delete from Treatment").executeUpdate();
		Query update = em.createNamedQuery("RemoveAllPatients");
		update.executeUpdate();
	}
	
	public PatientDAO(EntityManager em){
		this.em=em;
		this.treatmentDAO = new TreatmentDAO(em);
	}

}
