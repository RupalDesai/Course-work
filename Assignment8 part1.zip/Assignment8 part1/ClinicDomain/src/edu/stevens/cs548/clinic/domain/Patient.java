package edu.stevens.cs548.clinic.domain;

import java.io.Serializable;
import java.util.*;

import javax.persistence.*;

import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;

import static javax.persistence.CascadeType.REMOVE;

@NamedQueries({
	@NamedQuery(
		name="SearchPatientByPatientID",
		query="select p from Patient p where p.patientId = :pid"),
	@NamedQuery(
		name="CountPatientByPatientID",
		query="select count(p) from Patient p where p.patientId = :pid"),
	@NamedQuery(
			name="CountPatientByID",
			query="select count(p) from Patient p where p.id = :pid"),
	@NamedQuery(
		name = "RemoveAllPatients", 
		query = "delete from Patient p")
})

@Entity
@Table(name="PATIENT")
public class Patient implements Serializable {

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue
	private long id;
	private long patientId;
	private String name;

	@Temporal(TemporalType.DATE)
	private Date dateofbirth;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}



	public Date getDateofbirth() {
		return dateofbirth;
	}

	public void setDateofbirth(Date dateofbirth) {
		this.dateofbirth = dateofbirth;
	}



	// TODO JPA annotations (propagate deletion of patient to treatments)
	@OneToMany(mappedBy = "patient", cascade = REMOVE)
	@OrderBy
	private List<Treatment> treatments;

	protected List<Treatment> getTreatments() {
		return treatments;
	}

	protected void setTreatments(List<Treatment> treatments) {
		this.treatments = treatments;
	}
	
	@Transient
	private ITreatmentDAO treatmentDAO;
	
	public void setTreatmentDAO(ITreatmentDAO tdao){
		this.treatmentDAO =tdao;
	}
	/*
	 * Addition and deletion of treatments should be done in the provider aggregate.
	 */
  public List<Long> getTreatmentIds(){
		  List<Long>tids = new ArrayList<Long>();
		  for(Treatment t: this.getTreatments()){
			 tids.add(t.getId()); 
		  }
		  return tids;
	  }	
	 
	 
  public List<Long> getTreatmentIdsForService() {
			// TODO Auto-generated method stub
			List <Long> treatmentIds = new ArrayList<Long>();
			for(Treatment t : this.getTreatments()) {
				treatmentIds.add(t.getId());
			}
			return treatmentIds;
		}
  public void addTreatment(Treatment t){
		this.treatmentDAO.addTreatment(t);
		this.getTreatments().add(t);
		if(t.getPatient()!=this)
		    t.setPatient(this);
	}
	
  public void addDrugTreatment(String diagnosis, String drug, float dosage,Provider provider){
	  
	  DrugTreatment  treatment = new DrugTreatment();
	  treatment.setDiagnosis(diagnosis);
	  treatment.setDrug(drug);
	  treatment.setDosage(dosage);
	  treatment.setProvider(provider);
	  this.addTreatment(treatment);
  }
  
public void addDrugTreatment(String diagnosis, String drug, float dosage){
	  
	  DrugTreatment  treatment = new DrugTreatment();
	  treatment.setDiagnosis(diagnosis);
	  treatment.setDrug(drug);
	  treatment.setDosage(dosage);
	 
	  this.addTreatment(treatment);
  }
  
	
  
  public void addRadiologyTreatment(List<Date> dates,String diagnosis,Provider provider){
	 
	  Radiology radiology = new Radiology();
	  radiology.setDiagnosis(diagnosis);
	  radiology.setDates(dates);
	  radiology.setProvider(provider);
	  this.addTreatment(radiology);
  }
	
  
  public void addSurgeryTreatment(String diagnosis,Date date,Provider provider){
	  
	  Surgery surgery = new Surgery();
	  surgery.setDiagnosis(diagnosis);
	  surgery.setDate(date);
	  surgery.setProvider(provider);
	  this.addTreatment(surgery);
  }
  
 
  
  public void visitTreatment(long tid,ITreatmentVisitor visitor ) throws TreatmentExn{
	  
	  Treatment t = treatmentDAO.getTreatmentByDbId(tid);
	  if(t.getPatient() == this){
		  throw new TreatmentExn("Treatment access denied: patient ="+id+ ", treatment = "+tid);
	  }
	  t.visit(visitor);
	  
  }
  public void deleteTreatment(long tid)throws TreatmentExn {
	  Treatment t = treatmentDAO.getTreatmentByDbId(tid);
	  if(t.getPatient() == this){
		  throw new TreatmentExn(" Treatment access denied: patient ="+id+ ", treatment = "+tid);
	  }
	  treatmentDAO.deleteTreatment(t);
  }
  
  
  public void visitTreatments(ITreatmentVisitor visitor){
	  for(Treatment t : this.getTreatments()){
		  t.visit(visitor);
	  }
  }
  
  public <T> T exportTreatment(long tid, ITreatmentExporter<T> visitor) throws TreatmentExn {
		// Export a treatment without violated Aggregate pattern
		// Check that the exported treatment is a treatment for this patient.
		Treatment t = treatmentDAO.getTreatmentByDbId(tid);
		if (t.getPatient() != this) {
			throw new TreatmentExn("Inappropriate treatment access: patient = " + id + ", treatment = " + tid);
		}
		return t.export(visitor);
	}
  
  
	
}
