package edu.stevens.cs548.clinic.domain;

import javax.persistence.EntityManager;

public class TreatmentDAO implements ITreatmentDAO {
	
	private EntityManager em;
	
	

	public TreatmentDAO(EntityManager em) {
		this.em=em;
	}

	
	
	@Override
	public Treatment getTreatmentByDbId(long id) throws TreatmentExn {
		Treatment treatment = em.find(Treatment.class, id);
		if(treatment==null)		
		{
			throw new TreatmentExn("could not find Treatment:id ="+id);
		}
		else{
			return treatment;
		}	
	}
	
	
	@Override
	public long addTreatment(Treatment t) {
		em.persist(t);
		em.flush();
		return t.getId();
	}
	
	
	@Override
	public void deleteTreatment(Treatment t){
		em.remove(t);
	}

	

}
