package edu.stevens.cs548.clinic.domain;


import java.util.List;


//import edu.stevens.cs548.clinic.domain.Provider.Specialization;



public interface IProviderDAO {
	
	public static class ProviderExn extends Exception{
		private static final long serialVersionUID = 1L;
		
		public ProviderExn(String msg){
			super(msg);
		}
		
	}
	
	public Provider getProviderByDbId(long id)throws  ProviderExn;
	public List<Provider> getProviderByNameSpec(String name, String spec);
    public long addProvider(Provider prv) throws ProviderExn;
    public void delProvider(Provider prv) throws ProviderExn;
    public void delProviders();
	public Provider getProviderByNPI(long npi) throws ProviderExn;

}
