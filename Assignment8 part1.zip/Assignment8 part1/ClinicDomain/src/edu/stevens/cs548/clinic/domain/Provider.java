package edu.stevens.cs548.clinic.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.*;

import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;
//import edu.stevens.cs548.clinic.domain.RadiologyDate;
import static javax.persistence.CascadeType.REMOVE;

/**
 * Entity implementation class for Entity: Provider
 *
 */

@NamedQueries({
	@NamedQuery(name = "SearchProviderBynpi", query = "select p from Provider p where p.npi = :pid"
			),
	@NamedQuery(name = "CountProviderBynpi", query = "select count(p) from Provider p where p.npi = :pid"
			),
	@NamedQuery(name = "RemoveAllProvider", query = "delete from Provider p"
			) 
})
@Entity
@Table(name= "PROVIDER")

public class Provider implements Serializable {

	
	private static final long serialVersionUID = 1L;
		@Id
		@GeneratedValue
		private long id;
		private long npi;
		private String name;
		private String specialization;

		
		
		public long getId() {
			return id;
		}

		public void setId(long id) {
			this.id = id;
		}

		public long getNpi() {
			return npi;
		}
		public void setNpi(long npi) {
			this.npi= npi;
		}
		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getSpecialization() {
			return specialization;
		}

		public void setSpecialization(String specialization) {
			this.specialization = specialization;
		}
	   
		@OneToMany(mappedBy = "provider", cascade = REMOVE)
		@OrderBy
		private List<Treatment> treatments;

		protected List<Treatment> getTreatments() {
			return treatments;
		}

		protected void setTreatments(List<Treatment> treatments) {
			this.treatments = treatments;
		}
		@Transient
		private ITreatmentDAO treatmentDAO;
		
		public void setTreatmentDAO(ITreatmentDAO tdao){
			this.treatmentDAO =tdao;
		}
		/*
		 * Addition and deletion of treatments should be done in the provider aggregate.
		 */
public List<Long> getTreatmentIds(){
	  List<Long>tids = new ArrayList<Long>();
	  for(Treatment t: this.getTreatments()){
		 tids.add(t.getId()); 
	  }
	  return tids;
  }


public void addTreatment(Treatment t){
	this.treatmentDAO.addTreatment(t);
	this.getTreatments().add(t);
	if(t.getProvider()!=this)
	    t.setProvider(this);
}
		
public Treatment addDrugTrmt(String diagnosis, String drug, float dosage,Patient patient){
	  
	  DrugTreatment  treatment = new DrugTreatment();
	  treatment.setDiagnosis(diagnosis);
	  treatment.setDrug(drug);
	  treatment.setDosage(dosage);
	  treatment.setPatient(patient);
	  this.addTreatment(treatment);
	  return treatment;
}



public long addDrugTreatment(String diagnosis, String drug, float dosage,Patient patient){
			  
	  DrugTreatment  treatment = new DrugTreatment();
	  treatment.setDiagnosis(diagnosis);
	  treatment.setDrug(drug);
	  treatment.setDosage(dosage);
	  treatment.setPatient(patient);
	  this.addTreatment(treatment);
	  return treatment.getId();
  }
		

		  
public long addRadiologyTreatment(String diagnosis,List<Date> dates,Patient patient){
			 
	  Radiology radiology = new Radiology();
	  radiology.setDiagnosis(diagnosis);
	  radiology.setDates(dates);
	  radiology.setPatient(patient);
	  this.addTreatment(radiology);
	  return radiology.getId();
  }

			
public long addSurgeryTreatment(String diagnosis,Date date,Patient patient){
	  
	  Surgery surgery = new Surgery();
	  surgery.setDiagnosis(diagnosis);
	  surgery.setDate(date);
	  surgery.setPatient(patient);
	  this.addTreatment(surgery);
	  return surgery.getId();
  }
  

		 
		 
public void visitTreatment(long tid,ITreatmentVisitor visitor ) throws TreatmentExn{
		  
  Treatment t = treatmentDAO.getTreatmentByDbId(tid);
  if(t.getProvider() == this){
	  throw new TreatmentExn("Inappropriate Treatment access: patient ="+id+ ", treatment = "+tid);
	  }
	  t.visit(visitor);
	  
  }
	 
		 
		 
 public void deleteTreatment(long tid)throws TreatmentExn {
  Treatment t = treatmentDAO.getTreatmentByDbId(tid);
  if(t.getProvider() == this){
	  throw new TreatmentExn("Treatment access denied: patient ="+id+ ", treatment = "+tid);
	  }
	  treatmentDAO.deleteTreatment(t);
  }
		  
		  
 public void visitTreatments(ITreatmentVisitor visitor){
			  for(Treatment t : this.getTreatments()){
				  t.visit(visitor);
			  }
		  }
 
 
		  
public <T> T exportTreatment(long tid, ITreatmentExporter<T> visitor) throws TreatmentExn {
		// Export a treatment without violated Aggregate pattern
		// Check that the exported treatment is a treatment for this patient.
		Treatment treatment = treatmentDAO.getTreatmentByDbId(tid);
		if (treatment.getProvider() != this) {
			throw new TreatmentExn("Treatment access denied: patient = " + id + ", treatment = " + tid);
		}
		return treatment.export(visitor);
	}
  
  public Provider() {
		super();
		treatments = new ArrayList<Treatment>();
	}

		
public List<Long> getTreatmentIdsForService() {
		// TODO Auto-generated method stub
		List <Long> treatmentIds = new ArrayList<Long>();
		for(Treatment t : this.getTreatments()) {
			treatmentIds.add(t.getId());
		}
		return treatmentIds;
	}

}
