package edu.stevens.cs548.clinic.domain;

import java.util.Date;
import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2017-10-20T10:47:23.077+0530")
@StaticMetamodel(Radiology.class)
public class Radiology_ extends Treatment_ {
	public static volatile ListAttribute<Radiology, Date> dates;
}
