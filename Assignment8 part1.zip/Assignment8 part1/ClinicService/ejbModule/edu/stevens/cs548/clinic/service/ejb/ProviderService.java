package edu.stevens.cs548.clinic.service.ejb;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import edu.stevens.cs548.clinic.domain.IPatientDAO;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IProviderDAO;
import edu.stevens.cs548.clinic.domain.IProviderDAO.ProviderExn;
import edu.stevens.cs548.clinic.domain.IProviderFactory;
import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;
import edu.stevens.cs548.clinic.domain.ITreatmentExporter;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.PatientDAO;
import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.domain.ProviderDAO;
import edu.stevens.cs548.clinic.domain.ProviderFactory;
import edu.stevens.cs548.clinic.service.dto.util.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.util.ObjectFactory;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.RadiologyType;
import edu.stevens.cs548.clinic.service.dto.util.SurgeryType;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;


@Stateless(name="ProviderServiceBean")
public class ProviderService implements IProviderServiceLocal, IProviderServiceRemote {


	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ProviderService.class.getCanonicalName());

	private IProviderFactory providerFactory;
	private ProviderDtoFactory providerDtoFactory;
    private IProviderDAO providerDAO;
	private IPatientDAO patientDAO;
	
	public ProviderService() {
		// TODO initialize factories
		providerFactory = new ProviderFactory();
		providerDtoFactory = new ProviderDtoFactory();
		
	}
	
	@Inject @ClinicDomain
	private EntityManager em;
	
	@PostConstruct
	private void initialize(){
		providerDAO = new ProviderDAO(em);
		
	}
	
	
	
	@Override
	public ProviderDto getProvider(long id) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		try{
			
			Provider provider = providerDAO.getProviderByDbId(id);
			
			return providerDtoFactory.createProviderDto(provider);
		} catch(ProviderExn e){
			throw new ProviderServiceExn(e.getMessage());
		}
	}

	@Override
	public ProviderDto getProviderByNPI(long pid) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		try{
			
			Provider provider = providerDAO.getProviderByNPI(pid);
			return providerDtoFactory.createProviderDto(provider); 
		} catch(ProviderExn e){
			throw new ProviderServiceExn(e.getMessage());
		}
	}

	@Override
	public ProviderDto getProviderByDbId(long id) throws ProviderServiceExn {
		try{
			
			Provider provider = providerDAO.getProviderByDbId(id);
			
			return providerDtoFactory.createProviderDto(provider); 
		} catch(ProviderExn e){
			throw new ProviderServiceExn(e.getMessage());
		}
	}
	@Override
	public TreatmentDto getTreatment(long id, long tid)  
	throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
		// Export treatment DTO from patient aggregate
		try {
	
			Provider provider = providerDAO.getProviderByDbId(id);
			logger.info("done with provider.."+provider.toString());
			TreatmentExporter visitor = new TreatmentExporter();
			
			return provider.exportTreatment(tid, visitor);
		} catch (ProviderExn e) {
			throw new ProviderNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
	
	

	
	@Override
	public TreatmentDto[] getTreatments(long id, long[] tid)
			throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
		// TODO Auto-generated method stub
		try {
			Provider provider =  providerDAO.getProviderByDbId(id);
			TreatmentDto[] treatments = new TreatmentDto[tid.length];
			
			for(int i=0; i<tid.length; i++){
				TreatmentExporter visitor = new TreatmentExporter();
				provider.exportTreatment(tid[i], visitor);
				treatments[i]=visitor.getDto();
			}
			
			//return null;
			return treatments;
		} catch (ProviderExn e) {
			throw new ProviderNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
	
	@Resource(name="SiteInfo")
	private String siteInformation;
	
	
	public String siteInfo() {
		// TODO Auto-generated method stub
		return siteInformation;
	}

@Override

	
	
	public long addTreatment(TreatmentDto dto) throws ProviderServiceExn {
		long tid = 0;
		try {
			Patient patient = patientDAO.getPatientByDbId(dto.getPatient());
			Provider provider= providerDAO.getProviderByDbId(dto.getProvider());
			if (dto.getSurgery() != null) {
				tid = provider.addSurgeryTreatment(dto.getDiagnosis(), dto.getSurgery().getDate(), patient);
			} else if (dto.getRadiology() != null) {
				tid =  provider.addRadiologyTreatment(dto.getDiagnosis(), dto.getRadiology().getDate(), patient);
			} else if (dto.getDrugTreatment() != null) {
				tid =  provider.addDrugTreatment(dto.getDiagnosis(), dto.getDrugTreatment().getName(),
						dto.getDrugTreatment().getDosage(), patient);
			}
				
				
				
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		} catch (PatientExn e) {
			throw new ProviderServiceExn(e.toString());
		}
		return tid;
	}
	


	@Override
	public long addProvider(ProviderDto dto) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		try {
			Provider provider = providerFactory.createProvider(dto.getNpi(), dto.getName(), dto.getSpecialization());
			providerDAO.addProvider(provider);
			return provider.getId();
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
    
	@Override
	public long addSurgeryTreatment(TreatmentDto dto) throws ProviderServiceExn{
		long tid=0;
		patientDAO = new PatientDAO(em);
		try {
			Patient patient = patientDAO.getPatientByDbId(dto.getPatient());
			Provider provider= providerDAO.getProviderByDbId(dto.getProvider());
			tid = provider.addSurgeryTreatment(dto.getDiagnosis(), dto.getSurgery().getDate(), patient);
			
		} catch (PatientExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProviderExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return tid;
		
	}
	
	@Override
	public long addDrugTreatment(TreatmentDto dto) throws ProviderServiceExn{
		long tid=0;
		patientDAO = new PatientDAO(em);
		try {
			Patient patient = patientDAO.getPatientByDbId(dto.getPatient());
			Provider provider= providerDAO.getProviderByDbId(dto.getProvider());
			tid =  provider.addDrugTreatment(dto.getDiagnosis(), dto.getDrugTreatment().getName(),
					dto.getDrugTreatment().getDosage(), patient);
			
		} catch (PatientExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProviderExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
		return tid;
		
	}
	
	@Override
	public long addRadiologyTreatment(TreatmentDto dto) throws ProviderServiceExn{
		long tid=0;
		patientDAO = new PatientDAO(em);
		try {
			Patient patient = patientDAO.getPatientByDbId(dto.getPatient());
			Provider provider= providerDAO.getProviderByDbId(dto.getProvider());
			tid =  provider.addRadiologyTreatment(dto.getDiagnosis(), dto.getRadiology().getDate(), patient);
			
		} catch (PatientExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ProviderExn e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return tid;
		
	}
	
	


public class TreatmentExporter implements ITreatmentExporter<TreatmentDto> {
		
		private ObjectFactory factory = new ObjectFactory();
		
		private TreatmentDto dto;
		public TreatmentDto getDto(){
			return dto;
		}
		
		@Override
		public TreatmentDto exportDrugTreatment(long tid, String diagnosis, String drug,
				float dosage) {
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			DrugTreatmentType drugInfo = factory.createDrugTreatmentType();
			drugInfo.setDosage(dosage);
			drugInfo.setName(drug);
			dto.setDrugTreatment(drugInfo);
			return dto;
		}

		@Override
		public TreatmentDto exportRadiology(long tid, String diagnosis, List<Date> dates) {
			 
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			RadiologyType radioInfo = factory.createRadiologyType();
			radioInfo.setDate(dates);
			dto.setRadiology(radioInfo);
			return dto;
			
		}

		@Override
		public TreatmentDto exportSurgery(long tid, String diagnosis, Date date) {
			 
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			SurgeryType surgeryInfo = factory.createSurgeryType();
			surgeryInfo.setDate(date);
			dto.setSurgery(surgeryInfo);
			return dto;
			
		}
		
	}

@Override
public void deleteProvider() {
	// TODO Auto-generated method stub
	
	providerDAO.delProviders();
	
}
@Override
public void deleteTreatment(long id, long tid)
		throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
	try
	{
		Provider provider = providerDAO.getProviderByDbId(id);
		provider.deleteTreatment(tid);
	}
	catch (ProviderExn e) {
		throw new ProviderNotFoundExn(e.toString());
	} catch (TreatmentExn e) {
		throw new ProviderServiceExn(e.toString());
	}
}





}
