package edu.stevens.cs548.clinic.service.dto.util;

import java.util.ArrayList;
import java.util.List;

import edu.stevens.cs548.clinic.domain.Provider;

public class ProviderDtoFactory {
	
	ObjectFactory factory;
	
	public ProviderDtoFactory() {
		factory = new ObjectFactory();
	}
	
	public ProviderDto createProviderDto () {
		return factory.createProviderDto();
	}
	
	public ProviderDto createProviderDto (Provider pro) {
		ProviderDto dto = factory.createProviderDto();
		dto.setId(pro.getId());
		dto.setNpi(pro.getNpi());
		dto.setSpecialization(pro.getSpecialization());
		dto.setName(pro.getName());
		List <Long> t_ids = pro.getTreatmentIdsForService();
		dto.treatments = new ArrayList<>();
		for (int i=0; i<t_ids.size(); i++){
			dto.treatments.add(t_ids.get(i));
		}
		
		return dto;
	}

	
	
}
