package edu.stevens.cs548.clinic.service.dto.util;

import edu.stevens.cs548.clinic.domain.DrugTreatment;
import edu.stevens.cs548.clinic.domain.Radiology;
import edu.stevens.cs548.clinic.domain.Surgery;

public class TreatmentDtoFactory {
	
ObjectFactory factory;
	
	public TreatmentDtoFactory() {
		factory = new ObjectFactory();
	}
	
	public DrugTreatmentType createDrugTreatmentDto () {
		return factory.createDrugTreatmentType();
	}

	public SurgeryType createsurgeryTreatmentDto () {
		return factory.createSurgeryType();
	}
	public RadiologyType createRadiologyTreatmentDto () {
		return factory.createRadiologyType();
	}
	
	public TreatmentDto createTreatmentDto(){
		return factory.createTreatmentDto();
	}
	
	public TreatmentDto createTreatmentDto (DrugTreatment drug) {
		TreatmentDto treatment = factory.createTreatmentDto();
		treatment.setDiagnosis(drug.getDiagnosis());
		DrugTreatmentType drugtr = this.createDrugTreatmentDto();
		drugtr.setDosage(drug.getDosage());
		drugtr.setName(drug.getDrug());
		treatment.setDrugTreatment(drugtr);
		return treatment;
	}
	
	public TreatmentDto createRadiologyTreatmentdto(Radiology radiology) {
		TreatmentDto t = factory.createTreatmentDto();
		t.setDiagnosis(radiology.getDiagnosis());
		RadiologyType radiologytr = this.createRadiologyTreatmentDto();
	    radiologytr.getDate();
		t.setRadiology(radiologytr);
		return t;
	}


	public TreatmentDto createSurgeryTreatmentdto(Surgery surgery) {
		// TODO Auto-generated method stub
		TreatmentDto t = factory.createTreatmentDto();
		t.setDiagnosis(surgery.getDiagnosis());
		SurgeryType surgerytr = this.createsurgeryTreatmentDto();
		surgerytr.setDate(surgery.getDate());
		t.setSurgery(surgerytr);
		return t;
	}

}
