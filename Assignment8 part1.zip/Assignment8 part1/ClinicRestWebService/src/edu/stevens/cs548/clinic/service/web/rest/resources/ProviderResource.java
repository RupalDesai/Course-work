package edu.stevens.cs548.clinic.service.web.rest.resources;

import java.net.URI;
import java.util.logging.Logger;

import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import edu.stevens.cs548.clinic.service.dto.util.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.RadiologyType;
import edu.stevens.cs548.clinic.service.dto.util.SurgeryType;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDtoFactory;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceLocal;
import edu.stevens.cs548.clinic.service.representations.ProviderRepresentation;
import edu.stevens.cs548.clinic.service.representations.Representation;
import edu.stevens.cs548.clinic.service.representations.TreatmentRepresentation;




@Path("/provider")
@RequestScoped
public class ProviderResource {

	final static Logger logger = Logger.getLogger(ProviderResource.class.getCanonicalName());
	
	public class RecordNotCreated extends WebApplicationException{
		private static final long serialVersionUID = 1L;
		public RecordNotCreated(String message) {
	         super(Response.status(Response.Status.BAD_REQUEST)
	             .entity(message).type(Representation.MEDIA_TYPE).build());
		}
	}

	@Context
	private UriInfo uriInfo;
	private ProviderDtoFactory providerDtoFactory;
	private TreatmentDtoFactory treatmentDtoFactory;

	/**
	 * Default constructor.
	 */
	public ProviderResource() {
		providerDtoFactory = new ProviderDtoFactory();
		treatmentDtoFactory = new TreatmentDtoFactory();
	}


	@Inject
	private IProviderServiceLocal providerService;

	@GET
	@Path("site")
	@Produces("text/plain")
	public String getSiteInfo() {
		return providerService.siteInfo();
	}

	@POST
	@Consumes("application/xml")
	public Response addProvider(ProviderRepresentation providerRep,
			 @Context final HttpServletResponse response) {
		try {
			ProviderDto dto = providerDtoFactory.createProviderDto();
			dto.setNpi(providerRep.getProviderId());
			dto.setName(providerRep.getName());
			dto.setSpecialization(providerRep.getSpecialization());
			long id = providerService.addProvider(dto);
			UriBuilder ub = uriInfo.getAbsolutePathBuilder().path("{id}");
			URI url = ub.build(Long.toString(id));
			response.setStatus(HttpServletResponse.SC_CREATED);
			return Response.created(url).build();
		} catch (ProviderServiceExn e) {
			throw new RecordNotCreated("Unable to add Provider");
		}
	}

	@POST
	@Path("treatment")
	@Consumes("application/xml")
	public Response addTreatments(TreatmentRepresentation treatmentRep ) {
		try {
         
			TreatmentDto treatmentdto = treatmentDtoFactory.createTreatmentDto();
			treatmentdto.setDiagnosis(treatmentRep.getDiagnosis());
					
		    treatmentdto.setPatient(Representation.getId(treatmentRep.getPatient()));
			treatmentdto.setProvider(Representation.getId(treatmentRep.getProvider()));
		    
			
			long tid=-1;
			if (treatmentRep.getRadiology() != null) {
				RadiologyType radiologytrtDTO = treatmentDtoFactory.createRadiologyTreatmentDto();
				radiologytrtDTO.setDate(treatmentRep.getRadiology().getDate());
				treatmentdto.setRadiology(radiologytrtDTO);
				tid=providerService.addRadiologyTreatment(treatmentdto);
				treatmentdto.setId(tid);
			}
			
			
			if (treatmentRep.getDrugTreatment() != null) {
				
				DrugTreatmentType drugTrtDTO = treatmentDtoFactory.createDrugTreatmentDto();
				drugTrtDTO.setName(treatmentRep.getDrugTreatment().getName());
				drugTrtDTO.setDosage(treatmentRep.getDrugTreatment().getDosage());
				treatmentdto.setDrugTreatment(drugTrtDTO);
				tid=providerService.addDrugTreatment(treatmentdto);
				treatmentdto.setId(tid);
			
			}
			if (treatmentRep.getSurgery() != null) {
				SurgeryType surgerytrtDTO = treatmentDtoFactory.createsurgeryTreatmentDto();
				surgerytrtDTO.setDate(treatmentRep.getSurgery().getDate());
				treatmentdto.setSurgery(surgerytrtDTO);
				tid =providerService.addSurgeryTreatment(treatmentdto);
				treatmentdto.setId(tid);
			}
			UriBuilder ub = uriInfo.getAbsolutePathBuilder().path("{tid}");
			URI url = ub.build(Long.toString(tid));
		
			return Response.created(url).build();
			
		} catch (Exception e) {
			throw new RecordNotCreated("Unable to add treatment");
		}
	}

	
	/**
	 * Query methods for provider resources.
	 */

	@GET
	@Path("{id}")
	@Produces("application/xml")
	public ProviderRepresentation getProvider(@PathParam("id") String id) {
		try {
			long key = Long.parseLong(id);
			ProviderDto providerDTO = providerService.getProviderByDbId(key);
			ProviderRepresentation providerRep = new ProviderRepresentation(providerDTO, uriInfo);
			return providerRep;
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
	}

	@GET
	@Path("byNPI")
	@Produces("application/xml")
	public ProviderRepresentation getProviderByProviderId(@QueryParam("id") String providerId) {
		try {
			long pid = Long.parseLong(providerId);
			ProviderDto providerDTO = providerService.getProviderByNPI(pid);
			ProviderRepresentation providerRep = new ProviderRepresentation(providerDTO, uriInfo);
			return providerRep;
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
	}
	
	

	@GET
	@Path("{id}/treatments/{tid}")
	@Produces("application/xml")
	public TreatmentRepresentation getProviderTreatment(@PathParam("id") String id, @PathParam("tid") String tid) {
		try {
			TreatmentDto dto = providerService.getTreatment(Long.parseLong(id), Long.parseLong(tid));
			dto.setId(Long.parseLong(tid));
			dto.setProvider(Long.parseLong(id));
			TreatmentRepresentation treatmentRep = new TreatmentRepresentation(dto, uriInfo);
			return treatmentRep;
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
	}

}