package edu.stevens.cs548.clinic.service.ejb;

import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;

public interface IProviderService {
	
	public class ProviderServiceExn extends Exception {
		private static final long serialVersionUID = 1L;
		public ProviderServiceExn (String m) {
			super(m);
		}
	}
	public class ProviderNotFoundExn extends ProviderServiceExn {
		private static final long serialVersionUID = 1L;
		public ProviderNotFoundExn (String m) {
			super(m);
		}
	}
	public class TreatmentNotFoundExn extends ProviderServiceExn {
		private static final long serialVersionUID = 1L;
		public TreatmentNotFoundExn (String m) {
			super(m);
		}
	}

	public String siteInfo();

	public ProviderDto getProvider(long id) throws ProviderServiceExn;
	public ProviderDto getProviderByDbId(long id) throws ProviderServiceExn;
	public ProviderDto getProviderByNPI(long pid) throws ProviderServiceExn;
	public TreatmentDto[] getTreatments(long id, long[] tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;
	public TreatmentDto getTreatment(long id, long tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;
	
	
	
	public void deleteTreatment(long id, long tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;
	public void deleteProvider();
    
	public long addProvider(ProviderDto dto) throws ProviderServiceExn;
	long addTreatment(TreatmentDto treatmentdto)throws ProviderServiceExn;
	
 
	public long addRadiologyTreatment(TreatmentDto dto) throws ProviderServiceExn;
	public long addSurgeryTreatment(TreatmentDto dto) throws ProviderServiceExn;
	public long addDrugTreatment(TreatmentDto dto) throws ProviderServiceExn;

	

}
