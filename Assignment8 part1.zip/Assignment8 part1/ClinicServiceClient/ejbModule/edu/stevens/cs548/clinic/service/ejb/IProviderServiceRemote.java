package edu.stevens.cs548.clinic.service.ejb;

import javax.ejb.Remote;

import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.TreatmentNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;

@Remote
public interface IProviderServiceRemote extends IProviderService{

	TreatmentDto[] getTreatments(long id, long[] tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;

}
