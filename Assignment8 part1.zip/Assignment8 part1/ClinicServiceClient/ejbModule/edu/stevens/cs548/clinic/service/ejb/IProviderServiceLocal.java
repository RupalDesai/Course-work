package edu.stevens.cs548.clinic.service.ejb;

import javax.ejb.Local;

import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.TreatmentNotFoundExn;

@Local
public interface IProviderServiceLocal  extends IProviderService{

	TreatmentDto[] getTreatments(long id, long[] tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;




}
