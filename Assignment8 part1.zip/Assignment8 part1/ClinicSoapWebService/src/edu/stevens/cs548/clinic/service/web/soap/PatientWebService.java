package edu.stevens.cs548.clinic.service.web.soap;

import java.util.Date;

import javax.ejb.EJB;
import javax.jws.WebService;

import edu.stevens.cs548.clinic.service.dto.util.PatientDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.TreatmentNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientServiceLocal;
import edu.stevens.cs548.clinic.service.ejb.IPatientServiceRemote;

// Use JSR-181 annotations to specify Web service.
//Specify: endpoint interface (FQN), target namespace, service name, port name

@WebService(
		endpointInterface = "edu.stevens.cs548.clinic.service.web.soap.IPatientWebService", 
		targetNamespace = "http://cs548.stevens.edu/clinic/service/web/soap/patient", 
		serviceName = "PatientWebService", portName = "PatientWebPort")

public class PatientWebService implements IPatientWebService {

	 @EJB(beanName="PatientServiceBean")
	IPatientServiceLocal service;

    @EJB(beanName="PatientServiceBean")
    IPatientServiceRemote remoteservice;

	@Override
	public TreatmentDto[] getTreatments(long id, long[] tid) throws PatientNotFoundExn, TreatmentNotFoundExn,
			PatientServiceExn {
		return remoteservice.getTreatments(id, tid);
	}

	@Override
	public String siteInfo() {
		return remoteservice.siteInfo();
	}
/*
	@Override
	public long addPatient(PatientDto dto) throws PatientServiceExn {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public PatientDto getPatient(long id) throws PatientServiceExn {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PatientDto getPatientByPatId(long pid) throws PatientServiceExn {
		// TODO Auto-generated method stub
		return null;
	}
*/
	@Override
	public long addPatient(String name, Date dob, long patID) throws PatientServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.addonePatient(name,dob,patID);
	}

	@Override
	public PatientDto getPatientbyDbId(long id) throws PatientServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.getPatientByDbId(id);
	}

	@Override
	public PatientDto getPatientbyPatientID(long pid) throws PatientServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.getPatientByPatId(pid);
	}

	@Override
	public void deletePatient(String name,long id) throws PatientServiceExn {
		// TODO Auto-generated method stub
		remoteservice.deletePatient(name, id);
	}

	@Override
	public void addDrugTreatment(long id, String diagnosis, String drug, float dosage) throws PatientServiceExn {
		// TODO Auto-generated method stub
		remoteservice.addDrugTreatment(id, diagnosis, drug, dosage);
		
	}

	@Override
	public TreatmentDto getTreatment(long id, long tid)
			throws PatientNotFoundExn, TreatmentNotFoundExn, PatientServiceExn {
		// TODO Auto-generated method stub
		return null;
	}

}
