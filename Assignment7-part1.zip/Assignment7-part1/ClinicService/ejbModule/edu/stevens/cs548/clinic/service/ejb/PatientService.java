package edu.stevens.cs548.clinic.service.ejb;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import edu.stevens.cs548.clinic.domain.IPatientDAO;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IPatientFactory;
import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;
import edu.stevens.cs548.clinic.domain.ITreatmentExporter;
import edu.stevens.cs548.clinic.domain.ITreatmentVisitor;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.PatientDAO;
import edu.stevens.cs548.clinic.domain.PatientFactory;
import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.service.dto.util.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.util.ObjectFactory;
import edu.stevens.cs548.clinic.service.dto.util.PatientDto;
import edu.stevens.cs548.clinic.service.dto.util.PatientDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.RadiologyType;
import edu.stevens.cs548.clinic.service.dto.util.SurgeryType;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;

/**
 * Session Bean implementation class PatientService
 */
@Stateless(name="PatientServiceBean")
public class PatientService implements IPatientServiceLocal,
		IPatientServiceRemote {
	
	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(PatientService.class.getCanonicalName());

	private IPatientFactory patientFactory;
	
	private PatientDtoFactory patientDtoFactory;

	private IPatientDAO patientDAO;

	/**
	 * Default constructor.
	 */
	public PatientService() {
		patientFactory = new PatientFactory();
		patientDtoFactory = new PatientDtoFactory();
	}
	
	// TODO use dependency injection and EJB lifecycle methods to initialize DAOs
	@PostConstruct
	private void initialize()
	{
		patientDAO = new PatientDAO(em);
	}

	@Inject @ClinicDomain
	private EntityManager em;

	/**
	 * @see IPatientService#addPatient(String, Date, long)
	 */
	@Override
	public long addPatient(PatientDto dto) throws PatientServiceExn {
		// Use factory to create patient entity, and persist with DAO
		try {
			Patient patient = patientFactory.createPatient(dto.getPatientId(), dto.getName(), dto.getDob(), dto.getAge());
			patientDAO.addPatient(patient);
			return patient.getId();
		} catch (PatientExn e) {
			throw new PatientServiceExn(e.toString());
		}
	}

	/**
	 * @see IPatientService#getPatient(long)
	 */
	@Override
	public PatientDto getPatient(long id) throws PatientServiceExn {
		// TODO use DAO to get patient by database key
		try{
			Patient patient = patientDAO.getPatient(id);
			
			
			return patientDtoFactory.createPatientDto(patient); 
		} catch(PatientExn e){
			throw new PatientServiceExn(e.getMessage());
		}
	
	}

	/**
	 * @see IPatientService#getPatientByPatId(long)
	 */
	@Override
	public PatientDto getPatientByPatId(long pid) throws PatientServiceExn {
		// TODO use DAO to get patient by patient id
		try{
			Patient patient = patientDAO.getPatientByPatientId(pid);
			
			
			return patientDtoFactory.createPatientDto(patient); 
		} catch(PatientExn e){
			throw new PatientServiceExn(e.getMessage());
		}
		
	}
 
	
	
	/**
	 * @see IPatientService#getPatientByDbId(long)
	 */
	
	@Override
	public PatientDto getPatientByDbId(long id) throws PatientServiceExn {
		try
		{
			Patient patient = patientDAO.getPatient(id);
			return patientDtoFactory.createPatientDto(patient); 
		}		
		catch(PatientExn e)
		{
			throw new PatientServiceExn(e.toString());
		}
	}
	
	/**
	 * @see IPatientService#deletePatient(String,long)
	 */
	
	@Override
	public void deletePatient(String name, long id) throws PatientServiceExn {
		try
		{
			Patient patient = patientDAO.getPatientByPatientId(id);
			if(!name.equals(patient.getName()))
			{
				throw new PatientServiceExn("Tried to delete wrong patient: name = " + name + " , id = " + id);
			}
			else
			{
				patientDAO.deletePatient(name, id, patient);
			}
		}
		catch(PatientExn e)
		{
			throw new PatientServiceExn(e.toString());
		}
	}

	static class TreatmentPDOToDTO implements ITreatmentVisitor {

		private TreatmentDto dto;
		
		public TreatmentDto getDto(){
			return dto;
		}
		
		@Override
		public void visitDrugTreatment(long tid, String diagnosis, String drug, float dosage) {
			dto = new TreatmentDto();
			dto.setDiagnosis(diagnosis);
			DrugTreatmentType drugInfo = new DrugTreatmentType();
			drugInfo.setDosage(dosage);
			drugInfo.setName(drug);
			dto.setDrugTreatment(drugInfo);
		}

		
		@Override
		public void visitSurgery(long tid, String diagnosis, Date date) {
			// TODO Auto-generated method stub
			dto = new TreatmentDto();
			dto.setDiagnosis(diagnosis);
			SurgeryType st = new SurgeryType();
		    st.setDate(date);
			dto.setSurgery(st);
				
		}

		@Override
		public void visitRadiology(long tid, String diagnosis, List<Date> date) {
			// TODO Auto-generated method stub
			date= new ArrayList<Date>();
			dto = new TreatmentDto();
			dto.setDiagnosis(diagnosis);
			RadiologyType r = new RadiologyType();
		   r.setDate(date);
		   dto.setRadiology(r);  
			
		}

		
		
	}
	public class TreatmentExporter implements ITreatmentExporter<TreatmentDto> {
		
		private ObjectFactory factory = new ObjectFactory();
		private TreatmentDto dto;
		public TreatmentDto getDto(){
			return dto;
		}
		
		@Override
		public TreatmentDto exportDrugTreatment(long tid, String diagnosis, String drug,
				float dosage) {
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			DrugTreatmentType drugInfo = factory.createDrugTreatmentType();
			drugInfo.setDosage(dosage);
			drugInfo.setName(drug);
			dto.setDrugTreatment(drugInfo);
			return dto;
		}

		@Override
		public TreatmentDto exportRadiology(long tid, String diagnosis, List<Date> dates) {
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			dto.setId(tid);
			RadiologyType radiology = factory.createRadiologyType();
			radiology.getDate().addAll(dates);
			dto.setRadiology(radiology);
			return dto;
		}

		@Override
		public TreatmentDto exportSurgery(long tid, String diagnosis, Date date) {
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			dto.setId(tid);
			SurgeryType surgery = factory.createSurgeryType();
			surgery.setDate(date);
			dto.setSurgery(surgery);
			return dto;
		}
		
	}
	
	@Override
	public TreatmentDto[] getTreatments(long id, long[] tid)
			throws PatientNotFoundExn, TreatmentNotFoundExn, PatientServiceExn {
		// Export treatment DTO from patient aggregate
		try {
			Patient patient = patientDAO.getPatient(id);
			TreatmentDto[] treatments = new TreatmentDto[tid.length];
			
			for(int i=0; i<tid.length; i++){
				TreatmentExporter visitor = new TreatmentExporter();
				patient.exportTreatment(tid[i], visitor);
				treatments[i]=visitor.getDto();
			}
			
			
			return treatments;
		} catch (PatientExn e) {
			throw new PatientNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new PatientServiceExn(e.toString());
		}
	}

	@Override
	public void addDrugTreatment(long id, String diagnosis, String drug, float dosage) throws PatientNotFoundExn {
		try
		{   Provider p=new Provider();
			Patient patient = patientDAO.getPatient(id);
			patient.addDrugTreatment(diagnosis, drug, dosage, p.getNPI(), p.getProvider_name());
		}
		catch(PatientExn e)
		{
			throw new PatientNotFoundExn(e.toString());
		}
	}
	
	@Resource(name="SiteInfo")
	private String siteInformation;
	

	@Override
	public String siteInfo() {
		return siteInformation;
	}
	
	@Override
	public void deletePatients() {
		patientDAO.deletePatients();
	}
	@Override
	public void addRadiology(long id, List<Date> dates, String diagnosis) throws PatientServiceExn {
		try{
			Provider p = new Provider();
			Patient patient = patientDAO.getPatient(id);
			patient.addRadiology(diagnosis, dates,p.getNPI(), p.getProvider_name());
			
		} catch(PatientExn n){
			throw new PatientNotFoundExn(n.toString());
		}
		
	}

	@Override
	public void addSurgery(long id, Date date, String diagnosis) throws PatientServiceExn {
		try{
			Provider p = new Provider();
			Patient patient = patientDAO.getPatient(id);
			patient.addSurgery(diagnosis, date,p.getNPI(),p.getProvider_name());
		} catch(PatientExn n){
			throw new PatientNotFoundExn(n.toString());
		}
	
		
	}

	@Override
	public void deleteTreatment(long id, long tid) throws PatientNotFoundExn, TreatmentNotFoundExn, PatientServiceExn {
		// TODO Auto-generated method stub
		try
		{
			Patient patient = patientDAO.getPatient(tid);
			patient.deleteTreatment(tid);
		}
		catch(PatientExn e)
		{
			throw new PatientNotFoundExn(e.toString());
		}
		catch(TreatmentExn e){
			throw new PatientServiceExn(e.toString());
		}
	}
	
	public static int computeAge(Date dateOfBirth) {
		Calendar dob = Calendar.getInstance();  
		dob.setTime(dateOfBirth);  
		Calendar today = Calendar.getInstance();  
		int age = today.get(Calendar.YEAR) - dob.get(Calendar.YEAR);  
		if (today.get(Calendar.MONTH) < dob.get(Calendar.MONTH)) {
		  age--;  
		} else if (today.get(Calendar.MONTH) == dob.get(Calendar.MONTH)
		    && today.get(Calendar.DAY_OF_MONTH) < dob.get(Calendar.DAY_OF_MONTH)) {
		  age--;  
		}
		return age;
	}

	
	
	@Override
	public TreatmentDto getTreatment(long id, long trid) 
			throws PatientNotFoundExn, TreatmentNotFoundExn, PatientServiceExn {
		
		try {
			Patient patient = patientDAO.getPatient(id);
			TreatmentExporter visitor = new TreatmentExporter();
			return patient.exportTreatment(trid, visitor);
		} catch (PatientExn e) {
			throw new PatientNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new PatientServiceExn(e.toString());
		}
	}

	
	
}
