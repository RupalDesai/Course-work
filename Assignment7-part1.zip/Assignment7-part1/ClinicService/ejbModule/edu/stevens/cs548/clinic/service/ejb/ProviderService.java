package edu.stevens.cs548.clinic.service.ejb;

import java.util.Date;
import java.util.List;
import java.util.logging.Logger;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.persistence.EntityManager;

import edu.stevens.cs548.clinic.domain.IPatientDAO;
import edu.stevens.cs548.clinic.domain.IPatientDAO.PatientExn;
import edu.stevens.cs548.clinic.domain.IProviderDAO;
import edu.stevens.cs548.clinic.domain.IProviderDAO.ProviderExn;
import edu.stevens.cs548.clinic.domain.IProviderFactory;
import edu.stevens.cs548.clinic.domain.ITreatmentDAO.TreatmentExn;
import edu.stevens.cs548.clinic.domain.ITreatmentExporter;
import edu.stevens.cs548.clinic.domain.Patient;
import edu.stevens.cs548.clinic.domain.PatientDAO;
import edu.stevens.cs548.clinic.domain.Provider;
import edu.stevens.cs548.clinic.domain.ProviderDAO;
import edu.stevens.cs548.clinic.domain.ProviderFactory;
import edu.stevens.cs548.clinic.service.dto.util.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.util.ObjectFactory;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.RadiologyType;
import edu.stevens.cs548.clinic.service.dto.util.SurgeryType;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientServiceExn;


@Stateless(name="ProviderServiceBean")
public class ProviderService implements IProviderServiceLocal, IProviderServiceRemote {


	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(ProviderService.class.getCanonicalName());

	private IProviderFactory providerFactory;
	
	private ProviderDtoFactory providerDtoFactory;

	private IProviderDAO providerDAO;
	
	private IPatientDAO patientDAO;
	
	public ProviderService() {
		// TODO initialize factories
		providerFactory = new ProviderFactory();
		providerDtoFactory = new ProviderDtoFactory();
		
	}
	
	@Inject @ClinicDomain
	private EntityManager em;
	
	@PostConstruct
	private void initialize(){
		providerDAO = new ProviderDAO(em);
		
	}
	
	
	@Override
	public long addProvider(ProviderDto dto) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		try {
			Provider provider = providerFactory.createProvider(dto.getNpi(), dto.getName());
			providerDAO.addProvider(provider);
			return provider.getNPI();
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
    
	@Override
	public ProviderDto getProvider(long id) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		try{
			
			Provider provider = providerDAO.getProviderByNPI(id);
			
			return providerDtoFactory.createProviderDto(provider);
		} catch(ProviderExn e){
			throw new ProviderServiceExn(e.getMessage());
		}
	}

	@Override
	public ProviderDto getProviderByNPI(long pid) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		try{
			
			Provider provider = providerDAO.getProviderByNPI(pid);
			
			return providerDtoFactory.createProviderDto(provider); 
		} catch(ProviderExn e){
			throw new ProviderServiceExn(e.getMessage());
		}
	}

	@Override
	public ProviderDto getProviderByDbId(long id) throws ProviderServiceExn {
		try{
			
			Provider provider = providerDAO.getProviderByNPI(id);
			
			return providerDtoFactory.createProviderDto(provider); 
		} catch(ProviderExn e){
			throw new ProviderServiceExn(e.getMessage());
		}
	}

	
	@Resource(name="SiteInfo")
	private String siteInformation;
	
	
	public String siteInfo() {
		// TODO Auto-generated method stub
		return siteInformation;
	}

	
	@Override
	public void deleteTreatment(long id, long tid)
			throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
		try
		{
			Provider provider = providerDAO.getProviderByNPI(id);
			provider.deleteTreatment(tid);
		}
		catch (ProviderExn e) {
			throw new ProviderNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
	

	@Override
	public TreatmentDto getTreatment(long id, long tid)  
	throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
		// Export treatment DTO from patient aggregate
		try {
			Provider provider = providerDAO.getProviderByNPI(id);
			TreatmentExporter visitor = new TreatmentExporter();
			return provider.exportTreatment(tid, visitor);
		} catch (ProviderExn e) {
			throw new ProviderNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}
	
	

	
	@Override
	public TreatmentDto[] getTreatments(long id, long[] tid)
			throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
		// TODO Auto-generated method stub
		try {
			Provider provider =  providerDAO.getProviderByNPI(id);
			TreatmentDto[] treatments = new TreatmentDto[tid.length];
			
			for(int i=0; i<tid.length; i++){
				TreatmentExporter visitor = new TreatmentExporter();
				provider.exportTreatment(tid[i], visitor);
				treatments[i]=visitor.getDto();
			}
			
			//return null;
			return treatments;
		} catch (ProviderExn e) {
			throw new ProviderNotFoundExn(e.toString());
		} catch (TreatmentExn e) {
			throw new ProviderServiceExn(e.toString());
		}
	}

public class TreatmentExporter implements ITreatmentExporter<TreatmentDto> {
		
		private ObjectFactory factory = new ObjectFactory();
		
		private TreatmentDto dto;
		public TreatmentDto getDto(){
			return dto;
		}
		
		@Override
		public TreatmentDto exportDrugTreatment(long tid, String diagnosis, String drug,
				float dosage) {
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			DrugTreatmentType drugInfo = factory.createDrugTreatmentType();
			drugInfo.setDosage(dosage);
			drugInfo.setName(drug);
			dto.setDrugTreatment(drugInfo);
			return dto;
		}

		@Override
		public TreatmentDto exportRadiology(long tid, String diagnosis, List<Date> dates) {
			 
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			RadiologyType radioInfo = factory.createRadiologyType();
			radioInfo.setDate(dates);
			dto.setRadiology(radioInfo);
			return dto;
			
		}

		@Override
		public TreatmentDto exportSurgery(long tid, String diagnosis, Date date) {
			 
			TreatmentDto dto = factory.createTreatmentDto();
			dto.setDiagnosis(diagnosis);
			SurgeryType surgeryInfo = factory.createSurgeryType();
			surgeryInfo.setDate(date);
			dto.setSurgery(surgeryInfo);
			return dto;
			
		}
		
	}

@Override
public void deleteProvider() {
	// TODO Auto-generated method stub
	
	providerDAO.deleteProviders();
	
}


@Override

	
	
	public long addTreatment(TreatmentDto dto) throws ProviderServiceExn {
		long treatment_ids = 0;
		try {
			Patient patient = patientDAO.getPatient(dto.getPatient());
			Provider provider= providerDAO.getProviderByNPI(dto.getProvider());
			if (dto.getSurgery() != null) {
				treatment_ids = provider.addSurgeryTreatment(dto.getDiagnosis(), dto.getSurgery().getDate(), patient);
			} else if (dto.getRadiology() != null) {
				treatment_ids =  provider.addRadiology(dto.getDiagnosis(),dto.getRadiology().getDate(),provider.getNPI(),provider.getProvider_name());
			} else if (dto.getDrugTreatment() != null) {
				treatment_ids =  provider.addDrugTreatment(dto.getDiagnosis(), dto.getDrugTreatment().getName(),dto.getDrugTreatment().getDosage(),provider.getNPI());
			}
				
				
				
		} catch (ProviderExn e) {
			throw new ProviderServiceExn(e.toString());
		} catch (PatientExn e) {
			throw new ProviderServiceExn(e.toString());
		}
		return treatment_ids;
	}


@Override
public void addRadiology(long id, List<Date> dates, String diagnosis) throws PatientServiceExn {
	try{
		Patient pat = new Patient();
	    Provider pro;
	
		pro = providerDAO.getProviderByNPI(id);
		pro.addRadiology(diagnosis, dates,pat.getPatientId(), pat.getName());
	} catch (ProviderExn e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		
	}
	
}


@Override
public void addSurgery(long id, Date date, String diagnosis) throws PatientServiceExn {
	// TODO Auto-generated method stub
	try{
		Patient pat = new Patient();
		Provider pro = providerDAO.getProviderByNPI(id);
		pro.addSurgeryTreatment(diagnosis, date, pat);

	} catch (ProviderExn e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

}


@Override
public void addDrugTreatment(long id, String diagnosis, String drug, float dosage) throws PatientNotFoundExn {
	// TODO Auto-generated method stub
	try
	{   Patient pat=new Patient();
		Provider pro = providerDAO.getProviderByNPI(id);
		pro.addDrugTreatment(diagnosis, drug, dosage, id);
	
	} catch (ProviderExn e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}


@Override
public void deleteProviders() {
	// TODO Auto-generated method stub
	
}
	




}
