package edu.stevens.cs548.clinic.service.web.rest.resources;

import java.net.URI;

import javax.ejb.EJB;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import edu.stevens.cs548.clinic.service.dto.util.DrugTreatmentType;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.ProviderDtoFactory;
import edu.stevens.cs548.clinic.service.dto.util.RadiologyType;
import edu.stevens.cs548.clinic.service.dto.util.SurgeryType;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDtoFactory;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceLocal;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceRemote;
import edu.stevens.cs548.clinic.service.representations.ProviderRepresentation;
import edu.stevens.cs548.clinic.service.representations.Representation;
import edu.stevens.cs548.clinic.service.representations.TreatmentRepresentation;
@Path("/provider")
@RequestScoped
public class ProviderResource {

	

	@Context
	private UriInfo uriInfo;

	private ProviderDtoFactory providerDtoFactory;
	private TreatmentDtoFactory treatmentDtoFactory;

	/**
	 * Default constructor.
	 */
	public ProviderResource() {
		providerDtoFactory = new ProviderDtoFactory();
		treatmentDtoFactory = new TreatmentDtoFactory();
	}

	@EJB(beanName="ProviderServiceBean")
	private IProviderServiceRemote providerService;

	@GET
	@Path("site")
	@Produces("text/plain")
	public String getSiteInfo() {
		return providerService.siteInfo();
	}

	@POST
	@Path("provider")
	@Consumes("application/xml")
	public Response addProvider(ProviderRepresentation providerRep,
			 @Context final HttpServletResponse response) {
		try {
			ProviderDto dto = providerDtoFactory.createProviderDto();
			dto.setId(providerRep.getProviderId());
			dto.setName(providerRep.getName());
			long id = providerService.addProvider(dto);
			UriBuilder ub = uriInfo.getAbsolutePathBuilder().path("{id}");
			URI url = ub.build(Long.toString(id));
			response.setStatus(HttpServletResponse.SC_CREATED);
			return Response.created(url).build();
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException();
		}
	}

	@POST
	@Path("{ids}/treatments")
	@Consumes("application/xml")
	public Response addTreatments(TreatmentRepresentation treatmentRep,@PathParam("providerId") String providerId,
								  @HeaderParam("X-Patient") String patientURI
								
								 ) {
		try {

			TreatmentDto dto = treatmentDtoFactory.createTreatmentDto();
			dto.setDiagnosis(treatmentRep.getDiagnosis());
		    dto.setId(Representation.getId(treatmentRep.getId()));
			dto.setPatient(Representation.getId(treatmentRep.getPatient()));
			dto.setProvider(Representation.getId(treatmentRep.getProvider()));
			
			if (treatmentRep.getDrugTreatment() != null) {
				DrugTreatmentType drugDto = treatmentDtoFactory.createDrugTreatmentDto();
				drugDto.setDosage(treatmentRep.getDrugTreatment().getDosage());
				drugDto.setName(dto.getDrugTreatment().getName());
				dto.setDrugTreatment(drugDto);
			
			if (treatmentRep.getSurgery() != null) {
				RadiologyType radiologytrtDTO = treatmentDtoFactory.createRadiologyTreatmentDto();
				radiologytrtDTO.getDate().addAll(dto.getRadiology().getDate());
				dto.setRadiology(radiologytrtDTO);
			}
		
			}
			if (treatmentRep.getDrugTreatment() != null) {
				SurgeryType surgeryDto = treatmentDtoFactory.createsurgeryTreatmentDto();
				surgeryDto.setDate(dto.getSurgery().getDate());
				dto.setSurgery(surgeryDto);
			}
			
			long tid = providerService.addTreatment(dto);
			UriBuilder ub = uriInfo.getAbsolutePathBuilder().path("{tid}");
			URI url = ub.build(Long.toString(tid));
			return Response.created(url).build();
			
		} catch (Exception e) {
			throw new WebApplicationException();
		}
	}

	
	
	
	
	/**
	 * Query methods for provider resources.
	 */

	@GET
	@Path("{id}")
	@Produces("application/xml")
	public ProviderRepresentation getProvider(@PathParam("id") String id) {
		try {
			long key = Long.parseLong(id);
			ProviderDto providerDTO = providerService.getProviderByDbId(key);
			ProviderRepresentation providerRep = new ProviderRepresentation(providerDTO, uriInfo);
			return providerRep;
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
	}

	@GET
	@Path("by_NPI")
	@Produces("application/xml")
	public ProviderRepresentation getProviderByProviderId(@QueryParam("id") String providerId) {
		try {
			long pid = Long.parseLong(providerId);
			ProviderDto providerDTO = providerService.getProviderByNPI(pid);
			ProviderRepresentation providerRep = new ProviderRepresentation(providerDTO, uriInfo);
			return providerRep;
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
	}

	@GET
	@Path("{id}/treatments/{tids}")
	@Produces("application/xml")
	public TreatmentRepresentation getProviderTreatment(@PathParam("id") String id, @PathParam("tids") String tid) {
		try {
			TreatmentDto treatment = providerService.getTreatment(Long.parseLong(id), Long.parseLong(tid));
			TreatmentRepresentation treatmentRep = new TreatmentRepresentation(treatment, uriInfo);
			return treatmentRep;
		} catch (ProviderServiceExn e) {
			throw new WebApplicationException(Response.Status.NOT_FOUND);
		}
	}

}