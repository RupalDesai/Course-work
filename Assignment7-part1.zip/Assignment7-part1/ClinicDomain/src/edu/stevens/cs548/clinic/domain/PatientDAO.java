package edu.stevens.cs548.clinic.domain;

import java.util.logging.Logger;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import java.util.*;

 //com.sun.xml.bind.v2.schemagen.xmlschema.List;

public class PatientDAO implements IPatientDAO {

	private EntityManager em;
	private TreatmentDAO treatmentDAO;
	
	public PatientDAO(EntityManager em) {
		this.em = em;
		this.treatmentDAO = new TreatmentDAO(em);
	}

	@SuppressWarnings("unused")
	private Logger logger = Logger.getLogger(PatientDAO.class.getCanonicalName());

	@Override
	public long addPatient(Patient patient) throws PatientExn {
		long pid = patient.getPatientId();
		TypedQuery<Patient> query =em.createNamedQuery("SearchPatientByPatientID",Patient.class).setParameter("pid",pid);
		List<Patient> patients=query.getResultList();
	//	Long numExisting = (Long) query.getSingleResult();
		if (patients.size() < 1) {
			// TODO add to database (and sync with database to generate primary key)
			// Don't forget to initialize the patient aggregate with a treatment DAO
			em.persist(patient);
			patient.setTreatmentDAO(this.treatmentDAO);
				
		//	throw new IllegalStateException("Unimplemented");
			
		} else {
			Patient patient1=patients.get(0);
			
			throw new PatientExn("Insertion: Patient with patient id (" + pid + ") already exists."+patient1.getName());
		}
		return pid;
	}

	@Override
	public Patient getPatient(long id) throws PatientExn {
		// TODO retrieve patient using primary key
		Patient p=em.find(Patient.class,id);
		if(p==null){
			throw new PatientExn("Patient no Found:primary key="+id);
		}else{
			p.setTreatmentDAO(this.treatmentDAO);
			return p;
		}
		
	}

	@Override
	public Patient getPatientByPatientId(long pid) throws PatientExn {
		// TODO retrieve patient using query on patient id (secondary key)
		TypedQuery<Patient> query=
				em.createNamedQuery("SearchPatientByPatientID",Patient.class)
				.setParameter("pid",pid);
		 List<Patient> patients=query.getResultList();
		if(patients.size()>1)
			throw new PatientExn("Duplicate patient records:patient id:"+pid);
		else if(patients.size()<1)
			throw new PatientExn("Patient not found:patient id"+pid);
		else {
			Patient p= patients.get(0);
		p.setTreatmentDAO(this.treatmentDAO);
		return p;
		}
	}
	
	@Override
	public void deletePatients() {
		Query update = em.createNamedQuery("RemoveAllPatients");
		update.executeUpdate();
	}

	@Override
	public void deletePatient(String name, long id, Patient patient) {
		// TODO Auto-generated method stub
		em.remove(patient);

	}

}
