package edu.stevens.cs548.clinic.domain;
import edu.stevens.cs548.clinic.domain.Treatment;
import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
/**
 * Entity implementation class for Entity: Surgery
 *
 */
@Entity
@DiscriminatorValue("S")

public class Surgery  extends Treatment implements Serializable{
	@Temporal(TemporalType.DATE)
	@Column(name="date")
	private Date date;
	
	private static final long serialVersionUID = 1L;

	public Surgery() {
		super();
		this.setTreatmentType("S");
	}
	
	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
	//Provider pro=new Provider();
	@Override
	public <T> T export(ITreatmentExporter<T> visitor) {
		// TODO Auto-generated method stub
		 return visitor.exportSurgery(this.getId(), 
		   		   this.getDiagnosis(),
		   		   this.date);  
		   		
	
	}
	public void visit(ITreatmentVisitor visitor){
		visitor.visitSurgery(this.getId(),this.getDiagnosis(), this.date);
	}
}
