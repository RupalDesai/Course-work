package edu.stevens.cs548.clinic.domain;

import edu.stevens.cs548.clinic.domain.IProviderDAO.ProviderExn;

public class ProviderFactory implements IProviderFactory {

	@Override
	public Provider createProvider(long NPI, String pro_name) throws ProviderExn {
		// TODO Auto-generated method stub
		Provider provider=new Provider();
		provider.setNPI(NPI);
        provider.setProvider_name(pro_name);
		return provider;
	}

}
