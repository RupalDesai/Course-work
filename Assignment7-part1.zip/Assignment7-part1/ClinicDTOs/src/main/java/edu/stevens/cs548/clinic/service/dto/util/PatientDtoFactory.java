package edu.stevens.cs548.clinic.service.dto.util;

import java.util.ArrayList;
import java.util.List;

import edu.stevens.cs548.clinic.domain.Patient;

public class PatientDtoFactory {
	
	ObjectFactory factory;
	
	public PatientDtoFactory() {
		factory = new ObjectFactory();
	}
	
	public PatientDto createPatientDto () {
		return factory.createPatientDto();
	}
	
	public PatientDto createPatientDto (Patient pat) {
		
		PatientDto dto = factory.createPatientDto();
		/*
		 * TODO: Initialize the fields of the DTO.
		 */
		dto.setId(pat.getId());
		dto.setPatientId(pat.getPatientId());
		dto.setName(pat.getName());
		dto.setDob(pat.getBirthDate());
		
		
		
		List <Long> treatmentIds = pat.getTreatmentIds();
		dto.treatments = new ArrayList<>();
		for (int j=0; j<treatmentIds.size(); j++){
			dto.treatments.add(treatmentIds.get(j));
		}
		
		return dto;
	}
	
	public PatientDto createPatientDto (Patient pat,int age) {
		PatientDto dto = factory.createPatientDto();
		/*
		 * TODO: Initialize the fields of the DTO.
		 */
		dto.setId(pat.getId());
		dto.setName(pat.getName());
		dto.setPatientId(pat.getPatientId());
		dto.setDob(pat.getBirthDate());
		dto.setAge(age);
		
		
		
		List <Long> treatmentIds = pat.getTreatmentIds();
		dto.treatments = new ArrayList<>();
		for (int j=0; j<treatmentIds.size(); j++){
			dto.treatments.add(treatmentIds.get(j));
		}
		
		return dto;
	}

}
