package edu.stevens.cs548.clinic.service.dto.util;

import edu.stevens.cs548.clinic.domain.DrugTreatment;
import edu.stevens.cs548.clinic.domain.Radiology;
import edu.stevens.cs548.clinic.domain.Surgery;

public class TreatmentDtoFactory {
	
ObjectFactory factory;
	
	public TreatmentDtoFactory() {
		factory = new ObjectFactory();
	}
	
	public DrugTreatmentType createDrugTreatmentDto () {
		return factory.createDrugTreatmentType();
	}

	public SurgeryType createsurgeryTreatmentDto () {
		return factory.createSurgeryType();
	}
	public RadiologyType createRadiologyTreatmentDto () {
		return factory.createRadiologyType();
	}
	
	public TreatmentDto createTreatmentDto(){
		return factory.createTreatmentDto();
	}
	
	public TreatmentDto createTreatmentDto (DrugTreatment drug) {
		TreatmentDto dto = factory.createTreatmentDto();
		dto.setDiagnosis(drug.getDiagnosis());
		DrugTreatmentType d = this.createDrugTreatmentDto();
		d.setDosage(drug.getDosage());
		d.setName(drug.getDrug());
		dto.setDrugTreatment(d);
		return dto;
	}
	
	
	
	public TreatmentDto createRadiologyTreatmentdto(Radiology radiology) {
		TreatmentDto dto = factory.createTreatmentDto();
		dto.setDiagnosis(radiology.getDiagnosis());
		RadiologyType r = this.createRadiologyTreatmentDto();
		r.setDate(radiology.getDates());
		dto.setRadiology(r);
		return dto;
	}


	
	public TreatmentDto createSurgeryTreatmentdto(Surgery surgery) {
		// TODO Auto-generated method stub
		TreatmentDto dto = factory.createTreatmentDto();
		dto.setDiagnosis(surgery.getDiagnosis());
		SurgeryType s = this.createsurgeryTreatmentDto();
		s.setDate(surgery.getDate());
		dto.setSurgery(s);
		return dto;
	}

}
