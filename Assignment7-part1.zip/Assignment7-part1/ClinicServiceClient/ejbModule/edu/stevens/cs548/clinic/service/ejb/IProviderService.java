package edu.stevens.cs548.clinic.service.ejb;

import java.util.Date;
import java.util.List;

import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IPatientService.PatientServiceExn;

public interface IProviderService {
	
	public class ProviderServiceExn extends Exception {
		private static final long serialVersionUID = 1L;
		public ProviderServiceExn (String m) {
			super(m);
		}
	}
	public class ProviderNotFoundExn extends ProviderServiceExn {
		private static final long serialVersionUID = 1L;
		public ProviderNotFoundExn (String m) {
			super(m);
		}
	}
	public class TreatmentNotFoundExn extends ProviderServiceExn {
		private static final long serialVersionUID = 1L;
		public TreatmentNotFoundExn (String m) {
			super(m);
		}
	}

	

	public ProviderDto getProvider(long id) throws ProviderServiceExn;

	public ProviderDto getProviderByNPI(long pid) throws ProviderServiceExn;
	
	public TreatmentDto[] getTreatments(long id, long[] tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;
	
	TreatmentDto getTreatment(long id, long tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;
	
	ProviderDto getProviderByDbId(long id) throws ProviderServiceExn;
	
	
	
	
	public long addProvider(ProviderDto dto) throws ProviderServiceExn;
	
	long addTreatment(TreatmentDto treatmentdto)throws ProviderServiceExn;
	
    public void addRadiology(long id, List<Date> radiologyDates,String diagnosis) throws PatientServiceExn;
	
	public void addSurgery(long id, Date surgeryDate, String diagnosis) throws  PatientServiceExn;
	
	void addDrugTreatment(long id, String diagnosis, String drug, float dosage) throws PatientNotFoundExn;
	
	
	
	
	public void deleteTreatment(long id, long tid) throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn;
	
	public void deleteProvider();

    public void deleteProviders();
    
    
    
	public String siteInfo();
	

}
