/**
 * 
 */
package edu.stevens.cs548.clinic.service.web.soap;

import javax.ejb.EJB;
import javax.jws.WebService;

import edu.stevens.cs548.clinic.service.dto.util.ProviderDto;
import edu.stevens.cs548.clinic.service.dto.util.TreatmentDto;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.ProviderServiceExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderService.TreatmentNotFoundExn;
import edu.stevens.cs548.clinic.service.ejb.IProviderServiceRemote;

/**
 * @author yesha
 *
 */

@WebService(
		endpointInterface = "edu.stevens.cs548.clinic.service.web.soap.IProviderWebService", 
		targetNamespace = "http://cs548.stevens.edu/clinic/service/web/soap/provider", 
		serviceName = "ProviderWebService", portName = "ProviderWebPort")

public class ProviderWebService implements IProviderWebService {
	@EJB(beanName="ProviderServiceBean")
	IProviderServiceRemote remoteservice;

	/* (non-Javadoc)
	 * @see edu.stevens.cs548.clinic.service.web.soap.IProviderWebService#addProvider(edu.stevens.cs548.clinic.service.dto.util.ProviderDto)
	 */
	@Override
	public long addProvider(ProviderDto dto) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.addProvider(dto);
	}

	/* (non-Javadoc)
	 * @see edu.stevens.cs548.clinic.service.web.soap.IProviderWebService#getProvider(long)
	 */
	@Override
	public ProviderDto getProvider(long id) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.getProvider(id);
	}

	/* (non-Javadoc)
	 * @see edu.stevens.cs548.clinic.service.web.soap.IProviderWebService#getProviderByNPI(long)
	 */
	@Override
	public ProviderDto getProviderByNPI(long pid) throws ProviderServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.getProviderByNPI(pid);
	}

	/* (non-Javadoc)
	 * @see edu.stevens.cs548.clinic.service.web.soap.IProviderWebService#getTreatment(long, long[])
	 */
	@Override
	public TreatmentDto[] getTreatment(long id, long[] tid)
			throws ProviderNotFoundExn, TreatmentNotFoundExn, ProviderServiceExn {
		// TODO Auto-generated method stub
		return remoteservice.getTreatments(id, tid);
	}

	
	
	/* (non-Javadoc)
	 * @see edu.stevens.cs548.clinic.service.web.soap.IProviderWebService#siteInfo()
	 */
	@Override
	public String siteInfo() {
		// TODO Auto-generated method stub
		return remoteservice.siteInfo();
	}

	

}
