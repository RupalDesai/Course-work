package edu.stevens.cs548.clinic.domain;

import static javax.persistence.CascadeType.REMOVE;

import java.io.Serializable;
import java.lang.String;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

/**
 * Entity implementation class for Entity: Provider
 *
 */
@Entity
@Table(name="Provider")
public class Provider implements Serializable {

	
	private String Specialization;
	private String pro_name;   
	@Id
	private long NPI;
	private static final long serialVersionUID = 1L;

	
	public String getSpecialization() {
		return this.Specialization;
	}

	public void setSpecialization(String Specialization) {
		this.Specialization = Specialization;
	}   
	public String getPro_name() {
		return this.pro_name;
	}

	public void setPro_name(String pro_name) {
		this.pro_name = pro_name;
	}   
	public long getNPI() {
		return this.NPI;
	}

	public void setNPI(long NPI) {
		this.NPI = NPI;
	}
	@OneToMany(cascade=REMOVE, mappedBy="provider")
    @OrderBy
private List<Treatment> treatments;

protected List<Treatment> getTreatments() {
	return treatments;
}

protected void setTreatments(List<Treatment> treatments) {
	this.treatments = treatments;
}
	public Provider() {
		super();
		treatments= new ArrayList<Treatment>();
	}   
}
