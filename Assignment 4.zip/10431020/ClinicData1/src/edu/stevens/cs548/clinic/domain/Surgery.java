package edu.stevens.cs548.clinic.domain;

import edu.stevens.cs548.clinic.domain.Treatment;
import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;
/**
 * Entity implementation class for Entity: Surgery
 *
 */
@Entity
@DiscriminatorValue("S")
@Table(name="Surgery")
public class Surgery extends Treatment implements Serializable {
	@Temporal(TemporalType.DATE)
	@Column(name="date")
	private Date date;
	
	private static final long serialVersionUID = 1L;

	public Surgery() {
		super();
		this.setTreatmentType("S");
	}
	public Date getDate() {
		return this.date;
	}

	public void setDate(Date date) {
		this.date = date;
	}
}
