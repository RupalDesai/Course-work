package edu.stevens.cs548.clinic.domain;

import javax.annotation.Generated;
import javax.persistence.metamodel.ListAttribute;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value="Dali", date="2017-09-30T12:24:10.813+0530")
@StaticMetamodel(Provider.class)
public class Provider_ {
	public static volatile SingularAttribute<Provider, String> Specialization;
	public static volatile SingularAttribute<Provider, String> pro_name;
	public static volatile SingularAttribute<Provider, Long> NPI;
	public static volatile ListAttribute<Provider, Treatment> treatments;
}
