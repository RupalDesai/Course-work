package edu.stevens.cs548.clinic.domain;

import static javax.persistence.CascadeType.REMOVE;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.*;

import javax.persistence.*;



/**
 * Entity implementation class for Entity: Patient
 *
 */
@NamedQueries({
	@NamedQuery(
		name="SearchPatientByPatientID",
		query="select p from Patient p where p.patientId = :pid"),
	@NamedQuery(
		name="CountPatientByPatientID",
		query="select count(p) from Patient p where p.patientId = :pid"),
	@NamedQuery(
		name = "RemoveAllPatients", 
		query = "delete from Patient p")
})

/*
 * TODO
 */
@Entity
@Table(name="PATIENT")
public class Patient implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	// TODO JPA annotations

	@Id
	@GeneratedValue
	private long id;
	
	private long patientId;
	
	private String name;
	
	// TODO JPA annotation
	@Temporal(TemporalType.DATE)
	@Column(name="birthdate")
	private Date birthDate;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getPatientId() {
		return patientId;
	}

	public void setPatientId(long patientId) {
		this.patientId = patientId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Date getBirthDate() {
		return birthDate;
	}

	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}

	// TODO JPA annotations (propagate deletion of patient to treatments)
	 @OneToMany(cascade=REMOVE, mappedBy="patient")
	     @OrderBy
	private List<Treatment> treatments;

	protected List<Treatment> getTreatments() {
		return treatments;
	}

	protected void setTreatments(List<Treatment> treatments) {
		this.treatments = treatments;
	}
	
	/*
	 * Addition and deletion of treatments should be done in the provider aggregate.
	 */
       void addTreatment(Treatment t){
    	  this.getTreatments().add(t);
    	  if(t.getPatient()!=this)
    	  t.setPatient(this);
      }
       
       Provider p= new Provider();
       public void addDrugTreatment(String diagnosis,String drug,float dosage){
    	   /*
    	    * add provider parameter while adding treatment in patient
    	    * 
    	    */
          
           if(p.getSpecialization() =="DrugTreatment" )
           {
        	   DrugTreatment treatment= new DrugTreatment();
        	   treatment.setDiagnosis(diagnosis);
        	   treatment.setDrug(drug);
        	   treatment.setDosage(dosage);
        	   this.addTreatment(treatment);
           }
    	   
       }
       public void addSurgery(Date date){
    	   /*
    	    * add provider parameter while adding treatment in patient
    	    */
    	   if(p.getSpecialization()=="Surgeon"){
    	   Surgery surgery= new Surgery();
    	   surgery.setDate(date);
    	   this.addTreatment(surgery);}
       }
      public void addRadiology(Date dates){
    	  /*
    	   * add provider parameter while adding treatment in patient
    	   */
    	  if(p.getSpecialization()=="Radiology"){
    	  Radiology radiolody= new Radiology();
    	  
    	  }
      }
	public Patient() {
		super();
		/*
		 * TODO initialize lists
		 */
		treatments= new ArrayList<Treatment>();
	
	}
   
}
