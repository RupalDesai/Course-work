package edu.stevens.cs548.clinic.domain;

import edu.stevens.cs548.clinic.domain.Treatment;
import java.io.Serializable;

import javax.persistence.*;


import java.util.Date;
import java.util.List;
/**
 * Entity implementation class for Entity: Radiology
 *
 */
@Entity
@DiscriminatorValue("R")
@Table(name="Radiology")
public class Radiology extends Treatment implements Serializable {
    
	private static final long serialVersionUID = 1L;
	
	@ElementCollection
	@Temporal(TemporalType.DATE)
	@CollectionTable(
			name="rdates",
			joinColumns=@JoinColumn(name="id")
			)
   @Column(name ="radiologydates")
	private List<Date> dates;

   public List<Date> getDates() {
		return dates;
	}

	public void setDates(List<Date> dates) {
		this.dates = dates;
	}

public Radiology() {
		super();
		this.setTreatmentType("R");
		
	}   
	
   
}
